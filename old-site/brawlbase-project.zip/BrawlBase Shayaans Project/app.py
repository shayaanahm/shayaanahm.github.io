print("APP.PY STARTED")

from flask import Flask, render_template, request, redirect, url_for, session, flash
from config import Config
from models import db, User, Gym, Coach, Professional, Message

def create_app() -> Flask:
    app = Flask(__name__)
    app.config.from_object(Config)

    db.init_app(app)

    with app.app_context():
        db.create_all()

    # --- Helpers ---
    def current_user():
        uname = session.get("username")
        if not uname:
            return None
        return User.query.filter_by(username=uname).first()

    def login_required():
        if not session.get("username"):
            flash("Please log in first.")
            return False
        return True

    # --- Pages ---
    @app.get("/")
    def index():
        return render_template("index.html", user=current_user())

    @app.get("/dashboard")
    def dashboard():
        if not login_required():
            return redirect(url_for("login"))
        return render_template("dashboard.html", user=current_user())

    @app.route("/login", methods=["GET", "POST"])
    def login():
        if request.method == "POST":
            username = request.form.get("username", "").strip()
            password = request.form.get("password", "")
            user = User.query.filter_by(username=username).first()
            if user and user.check_password(password):
                session["username"] = user.username
                return redirect(url_for("dashboard"))
            flash("Invalid username or password.")
        return render_template("login.html", user=current_user())

    @app.route("/register", methods=["GET", "POST"])
    def register():
        if request.method == "POST":
            username = request.form.get("username", "").strip()
            password = request.form.get("password", "")
            martial_art = request.form.get("martial_art", "").strip()
            skill_level = request.form.get("skill_level", "").strip()
            location = request.form.get("location", "").strip()

            if len(username) < 3:
                flash("Username must be at least 3 characters.")
                return render_template("register.html", user=current_user())
            if len(password) < 6:
                flash("Password must be at least 6 characters.")
                return render_template("register.html", user=current_user())
            if User.query.filter_by(username=username).first():
                flash("Username already exists.")
                return render_template("register.html", user=current_user())

            u = User(
                username=username,
                martial_art=martial_art,
                skill_level=skill_level,
                location=location
            )
            u.set_password(password)
            db.session.add(u)
            db.session.commit()
            session["username"] = u.username
            return redirect(url_for("dashboard"))

        return render_template("register.html", user=current_user())

    @app.get("/logout")
    def logout():
        session.pop("username", None)
        return redirect(url_for("index"))

    @app.get("/profile/<username>")
    def profile(username: str):
        u = User.query.filter_by(username=username).first()
        if not u:
            flash("User not found.")
            return redirect(url_for("search"))
        return render_template("profile.html", user=current_user(), profile=u)

    @app.route("/search", methods=["GET", "POST"])
    def search():
        martial_art = request.values.get("martial_art", "").strip()
        skill_level = request.values.get("skill_level", "").strip()
        location = request.values.get("location", "").strip()

        q = User.query
        if martial_art:
            q = q.filter(User.martial_art.ilike(f"%{martial_art}%"))
        if skill_level:
            q = q.filter(User.skill_level.ilike(f"%{skill_level}%"))
        if location:
            q = q.filter(User.location.ilike(f"%{location}%"))

        results = q.order_by(User.username.asc()).all()
        return render_template(
            "search.html",
            user=current_user(),
            results=results,
            martial_art=martial_art,
            skill_level=skill_level,
            location=location
        )

    #NORMAL SERVICES PAGE
    @app.get("/services")
    def services():
        gyms = Gym.query.order_by(Gym.name.asc()).all()
        coaches = Coach.query.order_by(Coach.name.asc()).all()
        pros = Professional.query.order_by(Professional.name.asc()).all()
        return render_template(
            "services.html",
            user=current_user(),
            gyms=gyms,
            coaches=coaches,
            pros=pros
        )

    #ADMIN SERVICES PAGE (ADD/SEED)
    @app.route("/admin/services", methods=["GET", "POST"])
    def admin_services():
        if not login_required():
            return redirect(url_for("login"))

        if request.method == "POST":
            form_type = request.form.get("form_type")

            if form_type == "gym":
                db.session.add(Gym(
                    name=request.form.get("gym_name", "").strip(),
                    location=request.form.get("gym_location", "").strip(),
                    facilities=request.form.get("gym_facilities", "").strip()
                ))

            elif form_type == "coach":
                db.session.add(Coach(
                    name=request.form.get("coach_name", "").strip(),
                    specialism=request.form.get("coach_specialism", "").strip(),
                    location=request.form.get("coach_location", "").strip()
                ))

            elif form_type == "professional":
                db.session.add(Professional(
                    name=request.form.get("pro_name", "").strip(),
                    profession=request.form.get("pro_profession", "").strip(),
                    location=request.form.get("pro_location", "").strip()
                ))

            elif form_type == "seed":
                db.session.add(Gym(name="BrawlBase Gym", location="London", facilities="Ring"))
                db.session.add(Coach(name="Coach Saad", specialism="MMA", location="Manchester"))
                db.session.add(Professional(name="Dr Ali", profession="Physio", location="Leeds"))

            db.session.commit()
            return redirect(url_for("admin_services"))

        return render_template("admin_services.html", user=current_user())

    @app.route("/messages", methods=["GET", "POST"])
    def messages():
        if not login_required():
            return redirect(url_for("login"))

        user = current_user()
        prefill_receiver = request.args.get("to", "")
        if request.method == "POST":
            receiver = request.form.get("receiver", "").strip()
            content = request.form.get("content", "").strip()
            if not receiver or not content:
                flash("Receiver and message are required.")
            else:
                msg = Message(
                    sender_username=user.username,
                    receiver_username=receiver,
                    content=content
                )
                db.session.add(msg)
                db.session.commit()
                flash("Message sent.")

        inbox = Message.query.filter_by(receiver_username=user.username).order_by(Message.timestamp.desc()).all()
        sent = Message.query.filter_by(sender_username=user.username).order_by(Message.timestamp.desc()).all()
        return render_template(
    "messages.html",
    user=user,
    inbox=inbox,
    sent=sent,
    prefill_receiver=prefill_receiver
)

    return app

if __name__ == "__main__":
    app = create_app()
    app.run(host="127.0.0.1", port=5000, debug=True, use_reloader=False)
