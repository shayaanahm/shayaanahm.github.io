from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime

db = SQLAlchemy()

class User(db.Model):
    __tablename__ = "users"
    id = db.Column(db.Integer, primary_key=True)                 # UserID
    username = db.Column(db.String(50), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    martial_art = db.Column(db.String(50), nullable=True)
    skill_level = db.Column(db.String(30), nullable=True)
    location = db.Column(db.String(80), nullable=True)

    def set_password(self, raw_password: str) -> None:
        self.password_hash = generate_password_hash(raw_password)

    def check_password(self, raw_password: str) -> bool:
        return check_password_hash(self.password_hash, raw_password)

class Gym(db.Model):
    __tablename__ = "gyms"
    id = db.Column(db.Integer, primary_key=True)                 # GymID
    name = db.Column(db.String(80), nullable=False)
    location = db.Column(db.String(80), nullable=True)
    facilities = db.Column(db.Text, nullable=True)

class Coach(db.Model):
    __tablename__ = "coaches"
    id = db.Column(db.Integer, primary_key=True)                 # CoachID
    name = db.Column(db.String(80), nullable=False)
    specialism = db.Column(db.String(80), nullable=True)
    location = db.Column(db.String(80), nullable=True)

class Professional(db.Model):
    __tablename__ = "professionals"
    id = db.Column(db.Integer, primary_key=True)                 # ProfID
    name = db.Column(db.String(80), nullable=False)
    profession = db.Column(db.String(80), nullable=True)
    location = db.Column(db.String(80), nullable=True)

class Message(db.Model):
    __tablename__ = "messages"
    id = db.Column(db.Integer, primary_key=True)
    sender_username = db.Column(db.String(50), nullable=False)
    receiver_username = db.Column(db.String(50), nullable=False)
    content = db.Column(db.Text, nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
